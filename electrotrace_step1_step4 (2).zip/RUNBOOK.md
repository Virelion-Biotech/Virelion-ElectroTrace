# Step 2 (annotation loader) + Step 4 (false-positive forensics)

## What is in here
| File | Purpose |
|---|---|
| `src/electrotrace/wfdb_records.py` | One shared loader + audit for reference annotations. Default policy `error` reproduces old behaviour exactly. |
| `src/electrotrace/fp_analysis.py` | Pure-numpy false-positive forensics (timing bands, amplitude ratio, Stage-2 AUC, oracle threshold). |
| `scripts/diagnose_wfdb_annotations.py` | Look inside the 7 dropped INCART records before trusting any repair. |
| `scripts/incart_fp_offsets.py` | Run the frozen model, write JSON + per-FP CSV + figure. |
| `scripts/phase3_incart_ablation.py` | Now uses the loader, has `--annotation-policy`, writes package versions and an annotation audit. |
| `scripts/benchmark_certified_wfdb_incart.py` | Same loader wiring for gqrs/sqrs (verifies a repair against the detector's own output). |
| `tests/test_wfdb_records.py`, `test_fp_analysis.py`, `test_incart_forensics_scripts.py` | 31 tests, no network or wfdb needed. |

Apply with `git apply electrotrace_step1_step4.patch` (or unzip at the repo root).
`scripts/run_incart_external_full.py` is deliberately NOT touched: it trains the model, so wiring it is
part of the matched-evidence-table step, not a drive-by edit.

## 1. Gate: does the refactor preserve results?
    pytest -q tests/test_wfdb_records.py tests/test_fp_analysis.py tests/test_incart_forensics_scripts.py
    python -u scripts/phase3_incart_ablation.py --incart-dir .cache/physionet/incartdb \
        --model validation_reports/incart_mitbih_model_windowed_std_2026-09-09.skops \
        --output /tmp/ablation_default_policy.json
Compare `record_results` with `incart_phase3_ablation.json` from 2026-09-21. Same environment and model file
must give identical numbers for the 66 records. If not, stop and find out why before going further.

## 2. Diagnose the 7 excluded records
    python scripts/diagnose_wfdb_annotations.py --data-dir .cache/physionet/incartdb \
        --records I04 I17 I35 I44 I57 I72 I74 --output validation_reports/annotation_audit_incart_2026-09-21.json
Reading the table:
- Negatives only as a leading run, `cover` >= 0.5 and `drop_edges` says kept_after_dropping_edges: safe to include.
- Interior negatives, or `cover` near 0.2: reference is shifted or corrupt. Keep excluded, keep the reason in the report.
- Cross-check one record with the WFDB CLI (`rdann -r I04 -a atr | head`). If the C tool also shows negative
  times the file is at fault; if not, wfdb-python is misparsing and that is the real bug.
Only then run scripts with `--annotation-policy drop_edges` and report 75 vs 68 records side by side.

## 3. False-positive forensics (INCART = development data)
    python -u scripts/incart_fp_offsets.py --incart-dir .cache/physionet/incartdb \
        --model validation_reports/incart_mitbih_model_windowed_std_2026-09-09.skops
Outputs: `incart_fp_forensics.json`, `incart_fp_detail.csv`, `incart_fp_forensics.png`.
Hints, not verdicts (look at 3 records' traces before believing any of them):
| Pattern in the over-detecting group | Suggests |
|---|---|
| Stage-2 AUC high (about 0.95+) but PPV low | Ranking fine, threshold/calibration is the problem |
| Stage-2 AUC low (about 0.8 or less) | Stage-2 features do not separate these; needs new features or INCART in training folds |
| Mostly `duplicate_within_tolerance` / `post_qrs_near` | Stage 1 emits two candidates per QRS; fix merging/refractory, not Stage 2 |
| `post_qrs_t_window`, amp ratio 0.2-0.6 | T-wave-sized deflections |
| amp ratio < 0.1 | Baseline blips; Stage-1 prominence floor |
| High opposite-polarity fraction | Polarity handling |
Guardrail: `oracle_best_threshold` uses reference labels. It is for diagnosis only, never a setting to ship.
